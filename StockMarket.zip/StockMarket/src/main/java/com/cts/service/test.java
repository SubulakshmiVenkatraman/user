package com.cts.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.entity.Login;
import com.cts.entity.User;

public interface test extends JpaRepository<User, Integer>{

public User findByUserId(Long id);
public User findByUsername(String username);
public User findByPassword(String passWord);

}
