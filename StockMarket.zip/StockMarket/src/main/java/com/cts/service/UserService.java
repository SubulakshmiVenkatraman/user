package com.cts.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cts.entity.Login;
import com.cts.entity.User;

@Service
public class UserService {
	@Autowired
	test springRepository;

	@Transactional
	public User save(User user) {
//		user.setUsername(user.getUsername());
//		user.setPassword(user.getPassword());
//		user.setUserType(user.getUserType());
//		user.setE_Mail(user.getE_Mail());
//		user.setMobileNumber(user.getMobileNumber());
//		user.setConfirmed(user.getConfirmed());
		return springRepository.save(user);
	}
	@Transactional
	public List<User> findAll() {
		return springRepository.findAll();
	}
	

	@Transactional
	public void delete(User user) {
		springRepository.delete(user);
	}
	@Transactional
	public User findOne(Long id) {
		return springRepository.findByUserId(id);
	}
	
	 @Transactional
	    public String login(Login login) {
	        User user= springRepository.findByUsername(login.getUserName());
	        User pass= springRepository.findByPassword(login.getPassWord());
	        if(user == null && pass==null) {
	            throw new RuntimeException("User does not exist.");
	        }
	        else if((!user.getUsername().equals(login.getUserName()))&&(!user.getPassword().equals(login.getPassWord()))){
	            throw new RuntimeException("Password mismatch.");
	        }
	        else {
	        return "Login Success";
	        }
	    }
}
