package com.cts.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cts.entity.Login;
//
//import com.cts.entity.Login;
import com.cts.entity.User;

@Service
public class UserService {
	@Autowired
	test springRepository;

	@Transactional
	public User save(User user) {

		return springRepository.save(user);
	}
	@Transactional
	public List<User> findAll() {
		return springRepository.findAll();
	}
	

	@Transactional
	public void delete(User user) {
		springRepository.delete(user);
	}
	@Transactional
	public User findOne(Integer id) {
		return springRepository.getOne(id);
	}
	
 @Transactional
	    public String login(Login login) {
	        User user= springRepository.findByUsername(login.getUsername());
	        if(user == null) {
	            throw new RuntimeException("User does not exist.");
	        }
	        else if(!user.getPassword().equals(login.getPassword())){
	            throw new RuntimeException("Password mismatch.");
	        }
	        else {
	        return "Login Success";
	        }
	    }
}
