package com.cts.service;

public interface StockService {

}
